Step 1:- Open txt file from the folder for code

Step 2:- Copy all code 

Step 3:- Open your website dashboard or blog

Step 4:- Add HTML element 

Step 5:- Paste all code in your html element

Step 6:- Save file 